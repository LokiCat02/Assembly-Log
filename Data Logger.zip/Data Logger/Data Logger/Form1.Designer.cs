﻿namespace Data_Logger
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.LeadNameTxtBox = new System.Windows.Forms.TextBox();
            this.SelectProductBox = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.NameAssem1 = new System.Windows.Forms.TextBox();
            this.NameAssem2 = new System.Windows.Forms.TextBox();
            this.NameAssem3 = new System.Windows.Forms.TextBox();
            this.NameAssem4 = new System.Windows.Forms.TextBox();
            this.NameAssem5 = new System.Windows.Forms.TextBox();
            this.StartTimeLbl = new System.Windows.Forms.Label();
            this.GoButton = new System.Windows.Forms.Button();
            this.CancelButton = new System.Windows.Forms.Button();
            this.ExitButton = new System.Windows.Forms.Button();
            this.Specifications = new System.Windows.Forms.GroupBox();
            this.ACCtxtBox = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.ACVtxtBox = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.DCCtxtBox = new System.Windows.Forms.TextBox();
            this.DCVtxtBox = new System.Windows.Forms.TextBox();
            this.PSLbl = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.WperPPFDlbl = new System.Windows.Forms.Label();
            this.EffLbl = new System.Windows.Forms.Label();
            this.WattsLbl = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.FinishTimeLbl = new System.Windows.Forms.Label();
            this.NumberOfAssemblersBox = new System.Windows.Forms.NumericUpDown();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.Assembler1Lbl = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.KeepCalc = new System.Windows.Forms.Button();
            this.Specifications.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NumberOfAssemblersBox)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // LeadNameTxtBox
            // 
            this.LeadNameTxtBox.Font = new System.Drawing.Font("HP Simplified", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LeadNameTxtBox.Location = new System.Drawing.Point(188, 34);
            this.LeadNameTxtBox.Name = "LeadNameTxtBox";
            this.LeadNameTxtBox.Size = new System.Drawing.Size(216, 26);
            this.LeadNameTxtBox.TabIndex = 0;
            // 
            // SelectProductBox
            // 
            this.SelectProductBox.Font = new System.Drawing.Font("HP Simplified", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SelectProductBox.FormattingEnabled = true;
            this.SelectProductBox.Items.AddRange(new object[] {
            "SPYDRx",
            "SPYDRx Plus",
            "VYPRx",
            "RAY 22",
            "RAY 44",
            "RAZR3",
            "RAZR6"});
            this.SelectProductBox.Location = new System.Drawing.Point(832, 47);
            this.SelectProductBox.Name = "SelectProductBox";
            this.SelectProductBox.Size = new System.Drawing.Size(141, 27);
            this.SelectProductBox.TabIndex = 1;
            this.SelectProductBox.Text = "Select Product";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("HP Simplified", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(59, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(113, 21);
            this.label1.TabIndex = 3;
            this.label1.Text = "Leader\'s name:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("HP Simplified", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label2.Location = new System.Drawing.Point(698, 50);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(114, 21);
            this.label2.TabIndex = 4;
            this.label2.Text = "Select Product:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("HP Simplified", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label3.Location = new System.Drawing.Point(11, 16);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(204, 21);
            this.label3.TabIndex = 5;
            this.label3.Text = "Select number of assemblers";
            // 
            // NameAssem1
            // 
            this.NameAssem1.Font = new System.Drawing.Font("HP Simplified", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NameAssem1.Location = new System.Drawing.Point(188, 89);
            this.NameAssem1.Name = "NameAssem1";
            this.NameAssem1.Size = new System.Drawing.Size(216, 26);
            this.NameAssem1.TabIndex = 6;
            this.NameAssem1.Visible = false;
            // 
            // NameAssem2
            // 
            this.NameAssem2.Font = new System.Drawing.Font("HP Simplified", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NameAssem2.Location = new System.Drawing.Point(188, 128);
            this.NameAssem2.Name = "NameAssem2";
            this.NameAssem2.Size = new System.Drawing.Size(216, 26);
            this.NameAssem2.TabIndex = 7;
            this.NameAssem2.Visible = false;
            // 
            // NameAssem3
            // 
            this.NameAssem3.Font = new System.Drawing.Font("HP Simplified", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NameAssem3.Location = new System.Drawing.Point(188, 166);
            this.NameAssem3.Name = "NameAssem3";
            this.NameAssem3.Size = new System.Drawing.Size(216, 26);
            this.NameAssem3.TabIndex = 8;
            this.NameAssem3.Visible = false;
            // 
            // NameAssem4
            // 
            this.NameAssem4.Font = new System.Drawing.Font("HP Simplified", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NameAssem4.Location = new System.Drawing.Point(188, 205);
            this.NameAssem4.Name = "NameAssem4";
            this.NameAssem4.Size = new System.Drawing.Size(216, 26);
            this.NameAssem4.TabIndex = 9;
            this.NameAssem4.Visible = false;
            // 
            // NameAssem5
            // 
            this.NameAssem5.Font = new System.Drawing.Font("HP Simplified", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NameAssem5.Location = new System.Drawing.Point(188, 243);
            this.NameAssem5.Name = "NameAssem5";
            this.NameAssem5.Size = new System.Drawing.Size(216, 26);
            this.NameAssem5.TabIndex = 10;
            this.NameAssem5.Visible = false;
            // 
            // StartTimeLbl
            // 
            this.StartTimeLbl.AutoSize = true;
            this.StartTimeLbl.Font = new System.Drawing.Font("HP Simplified", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StartTimeLbl.Location = new System.Drawing.Point(151, 228);
            this.StartTimeLbl.Name = "StartTimeLbl";
            this.StartTimeLbl.Size = new System.Drawing.Size(80, 21);
            this.StartTimeLbl.TabIndex = 11;
            this.StartTimeLbl.Text = "Start Time";
            this.StartTimeLbl.Visible = false;
            // 
            // GoButton
            // 
            this.GoButton.BackColor = System.Drawing.Color.SteelBlue;
            this.GoButton.Font = new System.Drawing.Font("HP Simplified", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GoButton.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.GoButton.Location = new System.Drawing.Point(702, 92);
            this.GoButton.Name = "GoButton";
            this.GoButton.Size = new System.Drawing.Size(271, 48);
            this.GoButton.TabIndex = 12;
            this.GoButton.Text = "Go!";
            this.GoButton.UseVisualStyleBackColor = false;
            this.GoButton.Click += new System.EventHandler(this.GoButton_Click);
            // 
            // CancelButton
            // 
            this.CancelButton.BackColor = System.Drawing.Color.SteelBlue;
            this.CancelButton.Font = new System.Drawing.Font("HP Simplified", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CancelButton.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.CancelButton.Location = new System.Drawing.Point(419, 595);
            this.CancelButton.Name = "CancelButton";
            this.CancelButton.Size = new System.Drawing.Size(128, 34);
            this.CancelButton.TabIndex = 13;
            this.CancelButton.Text = "Start Over";
            this.CancelButton.UseVisualStyleBackColor = false;
            this.CancelButton.Click += new System.EventHandler(this.CancelButton_Click);
            // 
            // ExitButton
            // 
            this.ExitButton.BackColor = System.Drawing.Color.SteelBlue;
            this.ExitButton.Font = new System.Drawing.Font("HP Simplified", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ExitButton.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ExitButton.Location = new System.Drawing.Point(571, 596);
            this.ExitButton.Name = "ExitButton";
            this.ExitButton.Size = new System.Drawing.Size(128, 34);
            this.ExitButton.TabIndex = 14;
            this.ExitButton.Text = "Exit";
            this.ExitButton.UseVisualStyleBackColor = false;
            this.ExitButton.Click += new System.EventHandler(this.ExitButton_Click);
            // 
            // Specifications
            // 
            this.Specifications.BackColor = System.Drawing.Color.Transparent;
            this.Specifications.Controls.Add(this.ACCtxtBox);
            this.Specifications.Controls.Add(this.label7);
            this.Specifications.Controls.Add(this.label9);
            this.Specifications.Controls.Add(this.ACVtxtBox);
            this.Specifications.Controls.Add(this.label11);
            this.Specifications.Controls.Add(this.label12);
            this.Specifications.Controls.Add(this.DCCtxtBox);
            this.Specifications.Controls.Add(this.DCVtxtBox);
            this.Specifications.Controls.Add(this.PSLbl);
            this.Specifications.Controls.Add(this.label5);
            this.Specifications.Font = new System.Drawing.Font("HP Simplified", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Specifications.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.Specifications.Location = new System.Drawing.Point(46, 288);
            this.Specifications.Name = "Specifications";
            this.Specifications.Size = new System.Drawing.Size(501, 301);
            this.Specifications.TabIndex = 15;
            this.Specifications.TabStop = false;
            this.Specifications.Text = "Specifications";
            this.Specifications.Visible = false;
            // 
            // ACCtxtBox
            // 
            this.ACCtxtBox.Font = new System.Drawing.Font("HP Simplified", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ACCtxtBox.Location = new System.Drawing.Point(209, 223);
            this.ACCtxtBox.Name = "ACCtxtBox";
            this.ACCtxtBox.Size = new System.Drawing.Size(233, 26);
            this.ACCtxtBox.TabIndex = 12;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("HP Simplified", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label7.Location = new System.Drawing.Point(84, 124);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(89, 21);
            this.label7.TabIndex = 2;
            this.label7.Text = "DC Voltage:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("HP Simplified", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label9.Location = new System.Drawing.Point(83, 159);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(88, 21);
            this.label9.TabIndex = 4;
            this.label9.Text = "DC Current:";
            // 
            // ACVtxtBox
            // 
            this.ACVtxtBox.Font = new System.Drawing.Font("HP Simplified", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ACVtxtBox.Location = new System.Drawing.Point(209, 191);
            this.ACVtxtBox.Name = "ACVtxtBox";
            this.ACVtxtBox.Size = new System.Drawing.Size(233, 26);
            this.ACVtxtBox.TabIndex = 11;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("HP Simplified", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(84, 193);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(88, 21);
            this.label11.TabIndex = 6;
            this.label11.Text = "AC Voltage:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("HP Simplified", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(83, 226);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(87, 21);
            this.label12.TabIndex = 7;
            this.label12.Text = "AC Current:";
            // 
            // DCCtxtBox
            // 
            this.DCCtxtBox.Font = new System.Drawing.Font("HP Simplified", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DCCtxtBox.Location = new System.Drawing.Point(209, 157);
            this.DCCtxtBox.Name = "DCCtxtBox";
            this.DCCtxtBox.Size = new System.Drawing.Size(233, 26);
            this.DCCtxtBox.TabIndex = 10;
            // 
            // DCVtxtBox
            // 
            this.DCVtxtBox.Font = new System.Drawing.Font("HP Simplified", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DCVtxtBox.Location = new System.Drawing.Point(209, 122);
            this.DCVtxtBox.Name = "DCVtxtBox";
            this.DCVtxtBox.Size = new System.Drawing.Size(233, 26);
            this.DCVtxtBox.TabIndex = 9;
            // 
            // PSLbl
            // 
            this.PSLbl.AutoSize = true;
            this.PSLbl.Font = new System.Drawing.Font("HP Simplified", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PSLbl.Location = new System.Drawing.Point(194, 71);
            this.PSLbl.Name = "PSLbl";
            this.PSLbl.Size = new System.Drawing.Size(49, 23);
            this.PSLbl.TabIndex = 1;
            this.PSLbl.Text = "Here";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("HP Simplified", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(163, 36);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(193, 23);
            this.label5.TabIndex = 0;
            this.label5.Text = "Power supply required";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.label18);
            this.groupBox1.Controls.Add(this.label17);
            this.groupBox1.Controls.Add(this.WperPPFDlbl);
            this.groupBox1.Controls.Add(this.EffLbl);
            this.groupBox1.Controls.Add(this.WattsLbl);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.FinishTimeLbl);
            this.groupBox1.Controls.Add(this.StartTimeLbl);
            this.groupBox1.Font = new System.Drawing.Font("HP Simplified", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.groupBox1.Location = new System.Drawing.Point(575, 288);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(398, 301);
            this.groupBox1.TabIndex = 16;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Computations";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("HP Simplified", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(39, 260);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(92, 21);
            this.label18.TabIndex = 29;
            this.label18.Text = "Finish Time:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("HP Simplified", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(39, 228);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(85, 21);
            this.label17.TabIndex = 28;
            this.label17.Text = "Start Time:";
            // 
            // WperPPFDlbl
            // 
            this.WperPPFDlbl.AutoSize = true;
            this.WperPPFDlbl.Font = new System.Drawing.Font("HP Simplified", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.WperPPFDlbl.Location = new System.Drawing.Point(234, 114);
            this.WperPPFDlbl.Name = "WperPPFDlbl";
            this.WperPPFDlbl.Size = new System.Drawing.Size(116, 23);
            this.WperPPFDlbl.TabIndex = 5;
            this.WperPPFDlbl.Text = "WattsPPDLbl";
            this.WperPPFDlbl.Visible = false;
            // 
            // EffLbl
            // 
            this.EffLbl.AutoSize = true;
            this.EffLbl.Font = new System.Drawing.Font("HP Simplified", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EffLbl.Location = new System.Drawing.Point(234, 79);
            this.EffLbl.Name = "EffLbl";
            this.EffLbl.Size = new System.Drawing.Size(112, 23);
            this.EffLbl.TabIndex = 4;
            this.EffLbl.Text = "EfficiencyLbl";
            this.EffLbl.Visible = false;
            // 
            // WattsLbl
            // 
            this.WattsLbl.AutoSize = true;
            this.WattsLbl.Font = new System.Drawing.Font("HP Simplified", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.WattsLbl.Location = new System.Drawing.Point(234, 44);
            this.WattsLbl.Name = "WattsLbl";
            this.WattsLbl.Size = new System.Drawing.Size(103, 23);
            this.WattsLbl.TabIndex = 3;
            this.WattsLbl.Text = "WattageLbl";
            this.WattsLbl.Visible = false;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("HP Simplified", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(74, 114);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(149, 23);
            this.label10.TabIndex = 2;
            this.label10.Text = "WATTS per PPFD:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("HP Simplified", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(54, 82);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(168, 23);
            this.label8.TabIndex = 1;
            this.label8.Text = "POWER EFFICIENCY:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("HP Simplified", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(46, 44);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(175, 23);
            this.label6.TabIndex = 0;
            this.label6.Text = "POWER GENERATED:";
            // 
            // FinishTimeLbl
            // 
            this.FinishTimeLbl.AutoSize = true;
            this.FinishTimeLbl.Font = new System.Drawing.Font("HP Simplified", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FinishTimeLbl.Location = new System.Drawing.Point(151, 260);
            this.FinishTimeLbl.Name = "FinishTimeLbl";
            this.FinishTimeLbl.Size = new System.Drawing.Size(87, 21);
            this.FinishTimeLbl.TabIndex = 19;
            this.FinishTimeLbl.Text = "Finish Time";
            this.FinishTimeLbl.Visible = false;
            // 
            // NumberOfAssemblersBox
            // 
            this.NumberOfAssemblersBox.Font = new System.Drawing.Font("HP Simplified", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NumberOfAssemblersBox.Location = new System.Drawing.Point(58, 52);
            this.NumberOfAssemblersBox.Maximum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.NumberOfAssemblersBox.Name = "NumberOfAssemblersBox";
            this.NumberOfAssemblersBox.ReadOnly = true;
            this.NumberOfAssemblersBox.Size = new System.Drawing.Size(120, 26);
            this.NumberOfAssemblersBox.TabIndex = 17;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.SteelBlue;
            this.button2.Enabled = false;
            this.button2.Font = new System.Drawing.Font("HP Simplified", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button2.Location = new System.Drawing.Point(702, 149);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(271, 48);
            this.button2.TabIndex = 18;
            this.button2.Text = "Finish!";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.SteelBlue;
            this.button3.Font = new System.Drawing.Font("HP Simplified", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button3.Location = new System.Drawing.Point(58, 93);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(120, 33);
            this.button3.TabIndex = 20;
            this.button3.Text = "Add";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.SteelBlue;
            this.button4.Font = new System.Drawing.Font("HP Simplified", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button4.Location = new System.Drawing.Point(58, 134);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(120, 31);
            this.button4.TabIndex = 21;
            this.button4.Text = "Reset";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.Transparent;
            this.groupBox2.Controls.Add(this.button4);
            this.groupBox2.Controls.Add(this.button3);
            this.groupBox2.Controls.Add(this.NumberOfAssemblersBox);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Location = new System.Drawing.Point(445, 25);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(225, 244);
            this.groupBox2.TabIndex = 22;
            this.groupBox2.TabStop = false;
            // 
            // Assembler1Lbl
            // 
            this.Assembler1Lbl.AutoSize = true;
            this.Assembler1Lbl.BackColor = System.Drawing.Color.Transparent;
            this.Assembler1Lbl.Font = new System.Drawing.Font("HP Simplified", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Assembler1Lbl.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.Assembler1Lbl.Location = new System.Drawing.Point(62, 92);
            this.Assembler1Lbl.Name = "Assembler1Lbl";
            this.Assembler1Lbl.Size = new System.Drawing.Size(97, 21);
            this.Assembler1Lbl.TabIndex = 23;
            this.Assembler1Lbl.Text = "Assembler 1:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("HP Simplified", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Transparent;
            this.label4.Location = new System.Drawing.Point(62, 131);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(97, 21);
            this.label4.TabIndex = 24;
            this.label4.Text = "Assembler 2:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.Transparent;
            this.label14.Font = new System.Drawing.Font("HP Simplified", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Transparent;
            this.label14.Location = new System.Drawing.Point(62, 169);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(97, 21);
            this.label14.TabIndex = 25;
            this.label14.Text = "Assembler 3:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.Transparent;
            this.label15.Font = new System.Drawing.Font("HP Simplified", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.Transparent;
            this.label15.Location = new System.Drawing.Point(62, 208);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(97, 21);
            this.label15.TabIndex = 26;
            this.label15.Text = "Assembler 4:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.Transparent;
            this.label16.Font = new System.Drawing.Font("HP Simplified", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.Transparent;
            this.label16.Location = new System.Drawing.Point(62, 246);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(97, 21);
            this.label16.TabIndex = 27;
            this.label16.Text = "Assembler 5:";
            // 
            // KeepCalc
            // 
            this.KeepCalc.BackColor = System.Drawing.Color.SteelBlue;
            this.KeepCalc.Enabled = false;
            this.KeepCalc.Font = new System.Drawing.Font("HP Simplified", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.KeepCalc.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.KeepCalc.Location = new System.Drawing.Point(702, 208);
            this.KeepCalc.Name = "KeepCalc";
            this.KeepCalc.Size = new System.Drawing.Size(271, 48);
            this.KeepCalc.TabIndex = 28;
            this.KeepCalc.Text = "Next";
            this.KeepCalc.UseVisualStyleBackColor = false;
            this.KeepCalc.Click += new System.EventHandler(this.KeepCalc_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1016, 642);
            this.Controls.Add(this.KeepCalc);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.GoButton);
            this.Controls.Add(this.Assembler1Lbl);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.Specifications);
            this.Controls.Add(this.ExitButton);
            this.Controls.Add(this.CancelButton);
            this.Controls.Add(this.NameAssem5);
            this.Controls.Add(this.NameAssem4);
            this.Controls.Add(this.NameAssem3);
            this.Controls.Add(this.NameAssem2);
            this.Controls.Add(this.NameAssem1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.SelectProductBox);
            this.Controls.Add(this.LeadNameTxtBox);
            this.Name = "Form1";
            this.Text = "Data Logger";
            this.Specifications.ResumeLayout(false);
            this.Specifications.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NumberOfAssemblersBox)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox LeadNameTxtBox;
        private System.Windows.Forms.ComboBox SelectProductBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox NameAssem1;
        private System.Windows.Forms.TextBox NameAssem2;
        private System.Windows.Forms.TextBox NameAssem3;
        private System.Windows.Forms.TextBox NameAssem4;
        private System.Windows.Forms.TextBox NameAssem5;
        private System.Windows.Forms.Label StartTimeLbl;
        private System.Windows.Forms.Button GoButton;
        private System.Windows.Forms.Button CancelButton;
        private System.Windows.Forms.Button ExitButton;
        private System.Windows.Forms.GroupBox Specifications;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox ACCtxtBox;
        private System.Windows.Forms.TextBox ACVtxtBox;
        private System.Windows.Forms.TextBox DCCtxtBox;
        private System.Windows.Forms.TextBox DCVtxtBox;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label PSLbl;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label WperPPFDlbl;
        private System.Windows.Forms.Label EffLbl;
        private System.Windows.Forms.Label WattsLbl;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.NumericUpDown NumberOfAssemblersBox;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label FinishTimeLbl;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label Assembler1Lbl;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Button KeepCalc;
    }
}

