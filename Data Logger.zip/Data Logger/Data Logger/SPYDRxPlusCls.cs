﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data_Logger
{
    class SPYDRxPlusCls:SPYDRxCls
    {
        //Constructor
        public SPYDRxPlusCls(double DcV, double DcC, double AcV, double AcC) : base(DcV, DcC, AcV, AcC)
        {
        }

        //Calculates and returns power generated
        public new double Power_Generated()
        {
            return (_DC_Voltage * _DC_Current)+300;
        }

        //Calculates and return power efficiency 
        public new double power_eff()
        {
            return (Power_Generated() / (_AC_Voltage * _AC_Current)) * 100;
        }

        //Calculates and return wattage per PPFD
        public new double watss_per_PPFD()
        {
            return ((power_eff() * coeff_spydrx) / (Power_Generated() * (_AC_Voltage * _AC_Current))) * 500;
        }



    }
}
