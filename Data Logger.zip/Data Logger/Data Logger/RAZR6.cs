﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data_Logger
{
    class RAZR6 : IRAZR
    {

        private double DCV;
        private double DCC;
        private double ACV;
        private double ACC;
        private double coeff = 0.543;


        //Sets values
        public RAZR6()
        {
            DCV = 0;
            DCC = 0;
            ACV = 0;
            ACC = 0;
        }

        //Passes values
        public RAZR6(double DC_V, double DC_C, double AC_V, double AC_C)
        {
            DCV = DC_V;
            DCC = DC_C;
            ACV = AC_V;
            ACC = AC_C;
        }

        //Calculates power
        public double GetPowerDC()
        {
            return DCV * DCC;
        }

        //Calculates efficiency 
        public double GetEfficiency()
        {
            return GetPowerDC() / (ACV * ACC);
        }

        //Calculates Watts per PPFD
        public double GetWperPPFD()
        {
            return ((GetPowerDC() / (ACV * ACC)) * coeff) / ((GetPowerDC() / (ACV * ACC)) * 32);
        }

    }
}
