﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data_Logger
{
    class SPYDRxCls
    {

        public double _DC_Voltage { get; set; }
        public double _DC_Current { get; set; }
        public double _AC_Voltage { get; set; }
        public double _AC_Current { get; set; }
    
        public double coeff_spydrx = 0.1453;

        //sets values for voltage, current and temperature
        public SPYDRxCls(double DcV, double DcC, double AcV, double AcC)
        {
            this._DC_Voltage = DcV;
            this._DC_Current = DcC;
            this._AC_Voltage = AcV;
            this._AC_Current = AcC;

        }

        

        //Calculates power used by product
        public double Power_Generated()
        {
            return (_DC_Voltage * _DC_Current);
        }

        //Calculates efficiency
        public double power_eff()
        {
            return (Power_Generated() / (_AC_Voltage * _AC_Current))*100;
        }
       
        //Calculates watss per PPFD
        public double watss_per_PPFD()
        {
            return ((power_eff() * coeff_spydrx) / (Power_Generated() * (_AC_Voltage * _AC_Current)))*250;
        }



    }
}
