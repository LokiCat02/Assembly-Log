﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data_Logger
{
    class VYPR
    {
        private double _DC_Voltage = 0.0;
        private double _DC_Current = 0.0;
        private double _AC_Voltage = 0.0;
        private double _AC_Current = 0.0;
        
        public double coeff_vyprx = 0.1255;

        /// <summary>
        /// Gets and sets values to calulcate power, efficiency and Watts per PPFD
        /// </summary>
        public double DC_Voltage
        {
            get { return _DC_Voltage; }
            set { _DC_Voltage = value; }
        }
        public double DC_Current
        {
            get { return _DC_Current; }
            set { _DC_Current = value; }
        }
        public double AC_Voltage
        {
            get { return _AC_Voltage; }
            set { _AC_Voltage = value; }
        }
        public double AC_Current
        {
            get { return _AC_Current; }
            set { _AC_Current = value; }
        }
    

       //Calculate power used by product and return its value
        public double Power_Generated()
        {
            return (DC_Voltage * DC_Current);
        }

        //Calculates efficiency
        public double power_eff()
        {
            return (Power_Generated() / (AC_Voltage * AC_Current)) * 100;
        }


        //Calculates Watss per PPFD
        public double watss_per_PPFD()
        {
            return  ((power_eff() * coeff_vyprx) / (Power_Generated() * (AC_Voltage * AC_Current))) * 180;
        }


    }
}
