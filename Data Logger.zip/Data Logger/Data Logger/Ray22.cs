﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data_Logger
{
    class Ray22: PolymorphismforRays
    {
        private double coeff = 0.1212;

        public Ray22(double DcV = 0, double DcC = 0, double AcV = 0, double AcC = 0, double tmp = 0) : base(DcV, DcC, AcV, AcV, tmp)
        {

        }

        public override double GetWperPPFD()
        {
            double DCpower = DC_C * DC_V;
            double ACpower = AC_C * AC_V;

            return ((DCpower/ACpower)* coeff) / (DCpower * ACpower) * 40;
        }

        
    }
}
