﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Data_Logger
{

    public partial class Form1 : Form
    {

        
        public Form1()
        {
            InitializeComponent();
            this.CenterToScreen();
        }

        //Variables declaredo to gather the name of the assemblers, leader, power supplies and product to build.
        #region Variables
        int Num_Of_Assmb; 
        string AssName_1, AssName_2, 
               AssName_3, AssName_4,
               AssName_5, Leads_Name,
               product, start_time,
               numberofassemblers, finish_time,
               Ray22PS = "PLD400-SMT-10500",
               Ray44PS = "PLD500-SMT-21000",
               RAZ3RPS = "PLD320-SMT-31500",
               RAZR6PS = "PLD620-SMT-42000",
               SPYDRPS = "EUD-320L-8900",
               SPYDRPlUSPS = "EUD-600L-8900",
               VYPRPS = "HLG-600H-42B";

        #endregion


        string path = @"Production Log.csv"; //Variable to store location of the file

        private void GoButton_Click(object sender, EventArgs e)
        {

            

               start_time  = DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss tt"); //Get start assembly time
            bool checador = false; //Declared boolean variable to check if selected textboxes are empty


            /*This region was implemented to: 
             * ->Assure the selected number of assemblers required matches the names entered into the textboxes
             * ->There is a leader name
             * ->A product was selected*/
            #region Assemblers

            //Verifies that there is a name for the leader, a product was selected and the number of assemblers 
            if (string.IsNullOrEmpty(LeadNameTxtBox.Text) || SelectProductBox.SelectedItem == null || NumberOfAssemblersBox.Value == 0)
            {
                Specifications.Visible = false; //Hides specification box
                MessageBox.Show("Missing information!"); // Displays message
            }

            else if (!(string.IsNullOrEmpty(LeadNameTxtBox.Text) || SelectProductBox.SelectedItem == null) && NumberOfAssemblersBox.Value != 0)
            {

                Leads_Name = LeadNameTxtBox.Text;
                product = SelectProductBox.SelectedItem.ToString();
                numberofassemblers = NumberOfAssemblersBox.Value.ToString();

                //Starts a switch case statement based on the number of assemblers selected
                switch (NumberOfAssemblersBox.Value)
                {
                    case 1: //If only 1 assembler is needed then check for a name.
                        if (string.IsNullOrEmpty(NameAssem1.Text))
                        {
                            MessageBox.Show("Missing name for assembler"); //Display warning message if there is not name
                        }
                        else
                        {
                            AssName_1 = NameAssem1.Text; //Store name in variable
                            checador = true; 
                        }
                        break;
                    case 2: //If 2 assemblers are needed then check for names.
                        if (string.IsNullOrEmpty(NameAssem1.Text) || string.IsNullOrEmpty(NameAssem2.Text)) 
                        {
                            MessageBox.Show("Missing name for assembler");//Display warning message if there is not name
                        }
                        else
                        {
                            //Store names in variables
                            AssName_1 = NameAssem1.Text;
                            AssName_2 = NameAssem2.Text;
                            checador = true;
                        }
                        break;
                    case 3://If 3 assemblers are needed then check for names.
                        if (string.IsNullOrEmpty(NameAssem1.Text) || string.IsNullOrEmpty(NameAssem2.Text) || 
                            string.IsNullOrEmpty(NameAssem3.Text)) 
                        {
                            MessageBox.Show("Missing name for assembler");//Display warning message if there is not name
                        }
                        else
                        {
                            //Store names in variables
                            AssName_1 = NameAssem1.Text;
                            AssName_2 = NameAssem2.Text;
                            AssName_3 = NameAssem3.Text;
                            checador = true;
                        }
                        break;
                    case 4: //If 4 assemblers are needed then check for names.
                        if (string.IsNullOrEmpty(NameAssem1.Text) || string.IsNullOrEmpty(NameAssem2.Text) || 
                            string.IsNullOrEmpty(NameAssem3.Text) || string.IsNullOrEmpty(NameAssem4.Text)) 
                        {
                            MessageBox.Show("Missing name for assembler"); //Display warning message if there is not name
                        }
                        else
                        {
                            //Store names in variables
                            AssName_1 = NameAssem1.Text;
                            AssName_2 = NameAssem2.Text;
                            AssName_3 = NameAssem3.Text;
                            AssName_4 = NameAssem4.Text;
                            checador = true;
                        }
                        break;
                    case 5: //If 5 assemblers are needed then check for names.
                        if (string.IsNullOrEmpty(NameAssem1.Text) || string.IsNullOrEmpty(NameAssem2.Text) || 
                            string.IsNullOrEmpty(NameAssem3.Text) || string.IsNullOrEmpty(NameAssem4.Text) || 
                            string.IsNullOrEmpty(NameAssem5.Text))
                        {
                            MessageBox.Show("Missing name for assembler"); //Display warning message if there is not name
                        }
                        else
                        {
                            //Store names in variables
                            AssName_1 = NameAssem1.Text;
                            AssName_2 = NameAssem2.Text;
                            AssName_3 = NameAssem3.Text;
                            AssName_4 = NameAssem4.Text;
                            AssName_5 = NameAssem5.Text;
                            checador = true;
                        }
                        break;
                }


                //Displays power supply required for product
                switch(SelectProductBox.SelectedItem)
                {
                    case "SPYDRx":
                        PSLbl.Text = SPYDRPS;
                        break;
                    case "SPYDRx Plus":
                        PSLbl.Text = SPYDRPlUSPS;
                        break;
                    case "VYPRx":
                        PSLbl.Text = VYPRPS;
                        break;
                    case "RAY 22":
                        PSLbl.Text = Ray22PS;
                        break;
                    case "RAY 44":
                        PSLbl.Text = Ray44PS;
                        break;
                    case "RAZR3":
                        PSLbl.Text = RAZ3RPS;
                        break;
                    case "RAZR6":
                        PSLbl.Text = RAZR6PS;
                        break;


                }



            }

            #endregion 


            /*Locks textboxes and displays buttons if initial information was entered correclty*/
            if (!(string.IsNullOrEmpty(LeadNameTxtBox.Text) && SelectProductBox.SelectedItem == null) && checador == true)
            {
                Specifications.Visible = true; //Displays specifications area
                NumberOfAssemblersBox.ReadOnly = true; // Locks texbox for selection of #'s assembler
                button3.Enabled = false;            //Enables log data buttom
                button4.Enabled = false;            //Enables exit button
                GoButton.Enabled = false;           //Enables Go
                LeadNameTxtBox.Enabled = false;     //Locks textbox for the leader name
                SelectProductBox.Enabled = false;   //Locks selection of product
                NameAssem1.Enabled = false;         //Locks Texbox for Assembler 1
                NameAssem2.Enabled = false;         //Locks Texbox for Assembler 2
                NameAssem3.Enabled = false;         //Locks Texbox for Assembler 3        
                NameAssem4.Enabled = false;         //Locks Texbox for Assembler 4
                NameAssem5.Enabled = false;         //Locks Texbox for Assembler 5
                StartTimeLbl.Visible = true;
                StartTimeLbl.Text = start_time;     //Shows start time in label
                button2.Enabled = true;             //Enables Finish button
                
                NumberOfAssemblersBox.Enabled = false;   //disables count box for number of assemblers



                //Create file and add text only once to the file
                if (!File.Exists(path))
                {
                    using (StreamWriter sw = File.CreateText(path))
                    {
                        sw.WriteLine("Lead name, Product, Number of Assemblers, Start Time, Finish Time, Power Generated, Efficiency," +
                            "Watts per PPFD, Assembler 1, Assembler 2, Assembler 3, Assembler 4, Assembler 5");
                    }
                }
            }
        }

  
        private void button2_Click(object sender, EventArgs e)
        {

            
            double AC_V, AC_I, DC_V, DC_I, TEMP;        //Variables to hold values for AC & DC VI


            finish_time = finish_time = DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss tt");        //Holds finish assembly time of product

            FinishTimeLbl.Visible = true;
            FinishTimeLbl.Text = finish_time;           //Display finish time in label

      
            /*If the textboxes used to enter values for AC&DC power are null or empty, then display a message*/
            if (string.IsNullOrEmpty(DCVtxtBox.Text) || string.IsNullOrEmpty(DCCtxtBox.Text) || 
                string.IsNullOrEmpty(ACVtxtBox.Text) || string.IsNullOrEmpty(ACCtxtBox.Text) )
            {
                MessageBox.Show("Error!, Missing Power Information");
            }
            //If not then store values in variables
            else
            {
                    DC_V = Convert.ToDouble(DCVtxtBox.Text);
                    DC_I = Convert.ToDouble(DCCtxtBox.Text);   
                    AC_V = Convert.ToDouble(ACVtxtBox.Text);
                    AC_I = Convert.ToDouble(ACCtxtBox.Text);
                  

                //Calculate power and PPFD based on product selected.
                switch (SelectProductBox.SelectedItem)
                {

                    case "SPYDRx":
                        //Passes voltage and current values to SPYDRx class
                        SPYDRxCls spydrx = new SPYDRxCls(DC_V, DC_I, AC_V, AC_I);

                        /*Converts and stores calculated values of: 
                         *  Power Generated by the product
                         *  Efficiency of the power supply 
                         *  Watts per PPFD
                         */
                        string spydr_pwrgen = spydrx.Power_Generated().ToString("0.00");
                        string spydr_effciency = spydrx.power_eff().ToString("0.00");
                        string spydr_w_ppfd = spydrx.watss_per_PPFD().ToString("0.00");



                        //Displays calculated values on Windows Form
                        WattsLbl.Visible = true;
                        EffLbl.Visible = true;
                        WperPPFDlbl.Visible = true;
                        WattsLbl.Text = (spydr_pwrgen + " W");
                        EffLbl.Text = ("% " + spydr_effciency);
                        WperPPFDlbl.Text = (spydr_w_ppfd + " umoles");

                        //Logs results into Data Logger/Data Logger/bin/Debug
                        using (StreamWriter sw = File.AppendText(path))
                        {
                          sw.WriteLine(Leads_Name + "," + product + "," + numberofassemblers + "," 
                                       + start_time + "," + finish_time + "," + spydr_pwrgen + "," 
                                       + spydr_effciency + "," + spydr_w_ppfd + "," +
                                       AssName_1 + "," + AssName_2 + "," + AssName_3 + "," + 
                                       AssName_4 + "," + AssName_5);
                        }


                        break;

                    case "SPYDRx Plus":
                        //Passes voltage and current values to SPYDRx Plus class
                        SPYDRxCls spydrxplus = new SPYDRxCls(DC_V, DC_I, AC_V, AC_I);

                        /*Converts and stores calculated values of: 
                        *  Power Generated by the product
                        *  Efficiency of the power supply 
                        *  Watts per PPFD
                        */
                        string spydrplus_pwrgen = spydrxplus.Power_Generated().ToString("0.00");
                        string spydrplus_effciency = spydrxplus.power_eff().ToString("0.00");
                        string spydrplus_w_ppfd = spydrxplus.watss_per_PPFD().ToString("0.00");

                        //Displays calculated values on Windows Form
                        WattsLbl.Visible = true;
                        EffLbl.Visible = true;
                        WperPPFDlbl.Visible = true;
                        WattsLbl.Text = (spydrplus_pwrgen + " W");
                        EffLbl.Text = ("% " + spydrplus_effciency);
                        WperPPFDlbl.Text = (spydrplus_w_ppfd + " umoles");

                        //Logs results into Data Logger/Data Logger/bin/Debug
                        using (StreamWriter sw = File.AppendText(path))
                        {
                            sw.WriteLine(Leads_Name + "," + product + "," + numberofassemblers + ","
                                         + start_time + "," + finish_time + "," + spydrplus_pwrgen + ","
                                         + spydrplus_effciency + "," + spydrplus_w_ppfd + "," +
                                         AssName_1 + "," + AssName_2 + "," + AssName_3 + "," +
                                         AssName_4 + "," + AssName_5);
                        }

                        break;

                    case "VYPRx":
                        VYPR vyprx = new VYPR();

                        //Passes values to VYPR class
                        vyprx.DC_Voltage = DC_V;
                        vyprx.DC_Current = DC_I;
                        vyprx.AC_Voltage = AC_V;
                        vyprx.AC_Current = AC_I;
                     

                        /*Converts and stores calculated values of: 
                        *  Power Generated by the product
                        *  Efficiency of the power supply 
                        *  Watts per PPFD
                        */
                        string vyprx_pwrgen = vyprx.Power_Generated().ToString("0.00");
                        string vyprx_effciency = vyprx.power_eff().ToString("0.00");
                        string vyprx_w_ppfd = vyprx.watss_per_PPFD().ToString("0.00");

                        //Displays calculated values on Windows Form
                        WattsLbl.Visible = true;
                        EffLbl.Visible = true;
                        WperPPFDlbl.Visible = true;
                        WattsLbl.Text = (vyprx_pwrgen + " W");
                        EffLbl.Text = ("% " + vyprx_effciency);
                        WperPPFDlbl.Text = (vyprx_w_ppfd + " umoles");


                        //Logs results into Data Logger/Data Logger/bin/Debug
                        using (StreamWriter sw = File.AppendText(path))
                        {
                            sw.WriteLine(Leads_Name + "," + product + "," + numberofassemblers + ","
                                         + start_time + "," + finish_time + "," + vyprx_pwrgen + ","
                                         + vyprx_effciency + "," + vyprx_w_ppfd + "," +
                                         AssName_1 + "," + AssName_2 + "," + AssName_3 + "," +
                                         AssName_4 + "," + AssName_5);
                        }


                        break;

                        //Using Polymorphism
                    case "RAY 22":
                        Ray22 ray22 = new Ray22(DC_V, DC_I, AC_V, AC_I);
                        double Power_DC22 = DC_I * DC_V;
                        double Effiency22 = (Power_DC22/(AC_V * AC_I))*100;
                        double WpP22 = ray22.GetWperPPFD();

                        /*Converts and stores calculated values of: 
                        *  1. Power Generated by the product
                        *  2. Efficiency of the power supply 
                        *  3. Watts per PPFD
                        *  4. Displays calculated values on Windows Form
                        */
                        WattsLbl.Visible = true;
                        EffLbl.Visible = true;
                        WperPPFDlbl.Visible = true;
                        WattsLbl.Text = Power_DC22.ToString("0.00") + " W";
                        EffLbl.Text = "% " + Effiency22.ToString("0.00");
                        WperPPFDlbl.Text = WpP22.ToString("0.00") + " umoles";

                        //Logs results into Data Logger/Data Logger/bin/Debug
                        using (StreamWriter sw = File.AppendText(path))
                        {
                            sw.WriteLine(Leads_Name + "," + product + "," + numberofassemblers + ","
                                         + start_time + "," + finish_time + "," + Power_DC22 + ","
                                         + Effiency22 + "," + WpP22 + "," +
                                         AssName_1 + "," + AssName_2 + "," + AssName_3 + "," +
                                         AssName_4 + "," + AssName_5);
                        }

                        break;

                        
                    case "RAY 44": //Using Polymorphism
                        Ray44 ray44 = new Ray44(DC_V, DC_I, AC_V, AC_I);
                        double Power_DC44 = DC_I * DC_V;
                        double Effiency44 = (Power_DC44 / (AC_V * AC_I))*100;
                        double WpP44 = ray44.GetWperPPFD();

                        /*Converts and stores calculated values of: 
                        *  1. Power Generated by the product
                        *  2. Efficiency of the power supply 
                        *  3. Watts per PPFD
                        *  4. Displays calculated values on Windows Form
                        */
                        WattsLbl.Visible = true;
                        EffLbl.Visible = true;
                        WperPPFDlbl.Visible = true;
                        WattsLbl.Text = Power_DC44.ToString("0.00") + " W";
                        EffLbl.Text = "% " + Effiency44.ToString("0.00");
                        WperPPFDlbl.Text = WpP44.ToString("0.00") + " umoles";

                        //Logs results into Data Logger/Data Logger/bin/Debug
                        using (StreamWriter sw = File.AppendText(path))
                        {
                            sw.WriteLine(Leads_Name + "," + product + "," + numberofassemblers + ","
                                         + start_time + "," + finish_time + "," + Power_DC44 + ","
                                         + Effiency44 + "," + WpP44 + "," +
                                         AssName_1 + "," + AssName_2 + "," + AssName_3 + "," +
                                         AssName_4 + "," + AssName_5);
                        }

                        break;

                        
                    case "RAZR3":   //Using Interfaces
                        RAZR3 razr3 = new RAZR3(DC_V, DC_I, AC_V, AC_I);

                        double Power_RAZR3 = razr3.GetPowerDC();
                        double Effiency_RAZR3 = razr3.GetEfficiency();
                        double WpP_RAZR3 = razr3.GetWperPPFD();

                        /*Converts and stores calculated values of: 
                        *  Power Generated by the product
                        *  Efficiency of the power supply 
                        *  Watts per PPFD
                        */
                        WattsLbl.Visible = true;
                        EffLbl.Visible = true;
                        WperPPFDlbl.Visible = true;
                        WattsLbl.Text = Power_RAZR3.ToString("0.00") + " W";
                        EffLbl.Text = "% " + Effiency_RAZR3.ToString("0.00");
                        WperPPFDlbl.Text = WpP_RAZR3.ToString("0.00") + " umoles";

                        //Logs results into Data Logger/Data Logger/bin/Debug
                        using (StreamWriter sw = File.AppendText(path))
                        {
                            sw.WriteLine(Leads_Name + "," + product + "," + numberofassemblers + ","
                                         + start_time + "," + finish_time + "," + Power_RAZR3 + ","
                                         + Effiency_RAZR3 + "," + WpP_RAZR3 + "," +
                                         AssName_1 + "," + AssName_2 + "," + AssName_3 + "," +
                                         AssName_4 + "," + AssName_5);
                        }

                        break;

                    case "RAZR6":   //Using Interfaces
                        RAZR6 razr6 = new RAZR6(DC_V, DC_I, AC_V, AC_I);

                        double Power_RAZR6 = razr6.GetPowerDC();
                        double Effiency_RAZR6 = razr6.GetEfficiency();
                        double WpP_RAZR6 = razr6.GetWperPPFD();

                        /*Converts and stores calculated values of: 
                        *  1. Power Generated by the product
                        *  2. Efficiency of the power supply 
                        *  3. Watts per PPFD
                        *  4. Displays calculated values on Windows Form
                        */
                        WattsLbl.Visible = true;
                        EffLbl.Visible = true;
                        WperPPFDlbl.Visible = true;
                        WattsLbl.Text = Power_RAZR6.ToString("0.00") + " W";
                        EffLbl.Text = "% " + Effiency_RAZR6.ToString("0.00");
                        WperPPFDlbl.Text = WpP_RAZR6.ToString("0.00") + " umoles";

                        //Logs results into Data Logger/Data Logger/bin/Debug
                        using (StreamWriter sw = File.AppendText(path))
                        {
                            sw.WriteLine(Leads_Name + "," + product + "," + numberofassemblers + ","
                                         + start_time + "," + finish_time + "," + Power_RAZR6 + ","
                                         + Effiency_RAZR6 + "," + WpP_RAZR6 + ","+
                                         AssName_1 + "," + AssName_2 + "," + AssName_3 + "," +
                                         AssName_4 + "," + AssName_5);
                        }

                        break;
                }

   
                button2.Enabled = false;        //Disables the Finish button
                KeepCalc.Enabled = true;        //Enables the Next button 
                DCVtxtBox.Enabled = false;      //Disables textbox for DC Voltage
                DCCtxtBox.Enabled = false;      //Disables textbox for DC Current
                ACCtxtBox.Enabled = false;      //Disables textbox for AC Voltage
                ACVtxtBox.Enabled = false;      //Disables textbox for AC Current
             

            }
            


        }

        private void button3_Click(object sender, EventArgs e)
        {

            Num_Of_Assmb = Convert.ToInt32(NumberOfAssemblersBox.Value);

            //If the countbox for number of assemblers required is empty then display an error message
            if (NumberOfAssemblersBox.Value == 0 || NumberOfAssemblersBox == null)
            {
                MessageBox.Show("Number of assemblers can't be 0. Please select number between 1 and 5");
            }
            

            //Show textboxes bases on the number of assemblers required
            switch (Num_Of_Assmb)
            {
                case 1:
                    NameAssem1.Visible = true;
                    break;
                case 2:
                    NameAssem1.Visible = true;
                    NameAssem2.Visible = true;
                    break;
                case 3:
                    NameAssem1.Visible = true;
                    NameAssem2.Visible = true;
                    NameAssem3.Visible = true;
                    break;
                case 4:
                    NameAssem1.Visible = true;
                    NameAssem2.Visible = true;
                    NameAssem3.Visible = true;
                    NameAssem4.Visible = true;
                    break;
                case 5:
                    NameAssem1.Visible = true;
                    NameAssem2.Visible = true;
                    NameAssem3.Visible = true;
                    NameAssem4.Visible = true;
                    NameAssem5.Visible = true;
                    break;
            }
        }

        //Reset button for count box
        private void button4_Click(object sender, EventArgs e)
        {
            //Locks the textboxes used to enter name of the assemblers
            NameAssem1.Visible = false;
            NameAssem1.Text = "";
            NameAssem2.Visible = false;
            NameAssem2.Text = "";
            NameAssem3.Visible = false;
            NameAssem3.Text = "";
            NameAssem4.Visible = false;
            NameAssem4.Text = "";
            NameAssem5.Visible = false;
            NameAssem5.Text = "";

            NumberOfAssemblersBox.Value = 0;
        }

        //Exit button
        private void ExitButton_Click(object sender, EventArgs e)
        {
            //Confirms with user before closing the program
            DialogResult dialog = MessageBox.Show("Do you want to close the program", "Exit", MessageBoxButtons.YesNo);
            if ( dialog == DialogResult.Yes)
            {
                Application.Exit();
            }
          
            

        }

        //Next button
        private void KeepCalc_Click(object sender, EventArgs e)
        {
            /*Clears texboxes and labels for:
             * DC Voltage and current
             * AC Voltage and current
             * Temperature
             * Start time
             * End time
             * Wattage
             */
            WattsLbl.Text = "";                
            EffLbl.Text = "";
            WperPPFDlbl.Text = "";
            DCCtxtBox.Text = "";
            DCVtxtBox.Text = "";
            ACCtxtBox.Text = "";
            ACVtxtBox.Text = "";
            StartTimeLbl.Text = "";
            FinishTimeLbl.Text = "";

            /*Enables:
             * Go button
             * Next button
             * Textoxes for DC&AC Voltage and current
             * Temperature*/
            GoButton.Enabled = true;
            KeepCalc.Enabled = false;
            DCVtxtBox.Enabled = true;
            DCCtxtBox.Enabled = true;
            ACCtxtBox.Enabled = true;
            ACVtxtBox.Enabled = true;
  
        }

        //Resets form
        private void CancelButton_Click(object sender, EventArgs e)
        {
            this.Controls.Clear();

            this.InitializeComponent();
        }

    }
}
