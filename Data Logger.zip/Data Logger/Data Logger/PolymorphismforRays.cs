﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data_Logger
{
    class PolymorphismforRays
    {

        //This functions are for using polymorphism and abstraction
        protected double DC_V, DC_C, AC_V, AC_C, TMP;

        public  PolymorphismforRays(double DcV = 0, double DcC = 0, double AcV = 0, double AcC = 0, double tmp = 0)
        {
            DC_V = DcV;
            DC_C = DcC;
            AC_V = AcV;
            AC_C = AcC;
            TMP = tmp;
        }

        public virtual double GetWperPPFD()
        {
            return 0;
        }

    }
}
